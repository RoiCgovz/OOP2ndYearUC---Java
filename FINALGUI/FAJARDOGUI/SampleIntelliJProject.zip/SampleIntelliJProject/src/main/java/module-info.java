module com.sampleproject.sampleintellijproject {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires java.desktop;

    opens com.sampleproject.sampleintellijproject to javafx.fxml;
    exports com.sampleproject.sampleintellijproject;
}