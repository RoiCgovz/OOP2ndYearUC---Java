package com.sampleproject.sampleintellijproject;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.scene.text.Text;

import java.time.ZonedDateTime;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.*;

public class AddNotesController {

    @FXML
    public Text selectedDateText_notes; // To display the selected date

    @FXML
    private TextField eventTitleField_Notes; // To input event title

    @FXML
    private TextArea notesDescriptionArea; // To input event description

    @FXML
    public Button saveButton_notes; // To save the event

    @FXML
    private Button cancelButton_notes; // To cancel the event creation

    private ZonedDateTime selectedDate; // To store the selected date

    // This method will be called from the CalendarNavigationController
    public void setSelectedDate(ZonedDateTime selectedDate) {
        this.selectedDate = selectedDate;
        selectedDateText_notes.setText("Selected Date: " + selectedDate.toLocalDate().toString());
    }

    // Event handler for the "Save" button
    @FXML
    private void handleSaveEvent() {
        String notesTitle = eventTitleField_Notes.getText();
        String notesDescription = notesDescriptionArea.getText();

        if (notesTitle.isEmpty() || notesDescription.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please fill in all fields.");
        } else {
            String eventDetails = "Note Date: " + selectedDate.toLocalDate() + "\n" +
                    "Title: " + notesTitle + "\n" +
                    "Description: " + notesDescription + "\n" +
                    "----------------------------\n";

            String filePath = "notes.txt";
            Path path = Paths.get(filePath);

            try {
                // Check if file exists, create it if necessary
                if (!Files.exists(path)) {
                    Files.createFile(path); // Create file if it doesn't exist
                }

                try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
                    writer.write(eventDetails); // Write the new event details
                    writer.flush();
                    showAlert(Alert.AlertType.INFORMATION, "Saved", "Notes saved!");
                    backtoCalendarView();
                }
            } catch (IOException e) {
                e.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Error", "An error occurred while saving the note.");
            }
        }
    }

    // Event handler for the "Cancel" button
    @FXML
    private void handleCancelEvent() throws IOException {
        Stage stage = (Stage) cancelButton_notes.getScene().getWindow();
        backtoCalendarView();
        stage.show();
    }

    public void backtoCalendarView() throws IOException {
        switchScene("CALENDARFRONTPAGE.fxml");
    }

    // Method to switch scenes between pages
    private void switchScene(String fxmlFile) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
        Parent root = loader.load();
        Stage stage = (Stage) saveButton_notes.getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    // Helper method to show alerts
    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
