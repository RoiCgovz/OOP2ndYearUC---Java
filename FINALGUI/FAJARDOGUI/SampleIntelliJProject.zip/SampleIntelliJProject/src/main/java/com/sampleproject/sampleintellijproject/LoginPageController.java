package com.sampleproject.sampleintellijproject;

import java.io.*;
import java.util.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class LoginPageController {
    // Private Variables
    private final String USERS_FILE = "users.txt";

    // Front Page public variables
    public Button SignInButton;

    // Sign in page public variables
    public TextField SignIn_usernameTextField;
    public PasswordField SignIn_Password_Field;
    public Button confirmSigninButton;

    //Sign up public variables
    public TextField SignUp_usernametextfield;
    public PasswordField SignUp_passwordfield;
    public PasswordField SignUp_ConfirmPassword;

    // Helper method to switch scenes
    private void switchScene(String fxmlFile, ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
        Parent root = loader.load();
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }


    // Go Back to LoginPage/FrontPage
    public void goBacktoLoginPage(ActionEvent actionEvent) throws IOException {
        switchScene("MainFrontPage.fxml", actionEvent);
    }

    // Go to Sign in Page in FrontPage
    public void gotoSignIn(ActionEvent actionEvent) throws IOException {
        switchScene("SIGNINPAGE.fxml", actionEvent);
    }

    // Go to Sign Up page in FrontPage
    public void gotoSignUp(ActionEvent actionEvent) throws IOException {
        switchScene("SignUpPage.fxml", actionEvent);
    }

    // Handle Sign-Up action
   public void handleSignUp(ActionEvent actionEvent) {
        String username = SignUp_usernametextfield.getText();
        String password = SignUp_passwordfield.getText();
        String confirmPassword = SignUp_ConfirmPassword.getText();

        // Validation
        if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "All fields must be filled!");
            return;
        }

        if (!password.equals(confirmPassword)) {
            showAlert(Alert.AlertType.ERROR, "Password Error", "Passwords do not match!");
            return;
        }

        // Save credentials to file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(USERS_FILE, true))) {
            writer.write(username + ":" + password);
            writer.newLine();
            showAlert(Alert.AlertType.INFORMATION, "Success", "Account created successfully!");
            // Redirect to Login Page
            switchScene("MainFrontPage.fxml", actionEvent);
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "File Error", "Could not save user: " + e.getMessage());
        }
    }

    // Handle Sign-In action
    public void handleSignIn(ActionEvent actionEvent) {
        String username = SignIn_usernameTextField.getText();
        String password = SignIn_Password_Field.getText();

        // Validation
        if (username.isEmpty() || password.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Input Error", "All fields must be filled!");
            return;
        }

        // Check credentials in file
        try (Scanner scanner = new Scanner(new File(USERS_FILE))) {
            boolean isValidUser = false;

            while (scanner.hasNextLine()) {
                String[] credentials = scanner.nextLine().split(":");
                if (credentials.length == 2 && credentials[0].equals(username) && credentials[1].equals(password)) {
                    isValidUser = true;
                    break;
                }
            }

            if (isValidUser) {
                switchScene("CALENDARFRONTPAGE.fxml", actionEvent);
            } else {
                showAlert(Alert.AlertType.ERROR, "Login Error", "Invalid username or password!");
            }
        } catch (FileNotFoundException e) {
            showAlert(Alert.AlertType.ERROR, "File Error", "Could not read users file: " + e.getMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    // Helper method to show alerts
    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}