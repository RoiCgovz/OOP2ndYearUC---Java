package com.sampleproject.sampleintellijproject;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class CalendarNavigationController {

    private ZonedDateTime dateFocus;
    private ZonedDateTime today;

    @FXML
    private Text year;

    @FXML
    private Text month;

    @FXML
    private FlowPane calendar;

    @FXML
    void initialize() {
        dateFocus = ZonedDateTime.now();
        today = ZonedDateTime.now();
        drawCalendar();
    }

    @FXML
    void backOneMonth(ActionEvent event) {
        dateFocus = dateFocus.minusMonths(1);
        calendar.getChildren().clear();
        drawCalendar();
    }

    @FXML
    void forwardOneMonth(ActionEvent event) {
        dateFocus = dateFocus.plusMonths(1);
        calendar.getChildren().clear();
        drawCalendar();
    }

    @FXML
    private void logout(ActionEvent actionEvent) throws IOException {
        showLogoutConfirmation(actionEvent);
    }

    private void showLogoutConfirmation(ActionEvent actionEvent) throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Log Out");
        alert.setHeaderText("Do you want to log out?");
        alert.setContentText("Please choose your option.");

        ButtonType buttonTypeYes = new ButtonType("Yes");
        ButtonType buttonTypeNo = new ButtonType("No");

        alert.getButtonTypes().setAll(buttonTypeYes, buttonTypeNo);

        alert.showAndWait().ifPresent(response -> {
            if (response == buttonTypeYes) {
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("MainFrontPage.fxml"));
                    Parent root = loader.load();
                    Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                    Scene scene = new Scene(root);
                    stage.setScene(scene);
                    stage.show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void drawCalendar() {
        year.setText(String.valueOf(dateFocus.getYear()));
        month.setText(String.valueOf(dateFocus.getMonth()));

        int monthMaxDate = dateFocus.getMonth().maxLength();
        if (dateFocus.getYear() % 4 != 0 && monthMaxDate == 29) {
            monthMaxDate = 28;
        }

        // Get day of the week for the first day of the month (starting from Monday as 1, Sunday as 7)
        int dateOffset = ZonedDateTime.of(dateFocus.getYear(), dateFocus.getMonthValue(), 1, 0, 0, 0, 0, dateFocus.getZone())
                .getDayOfWeek().getValue();
        // Adjust day of the week if it is Sunday
        if (dateOffset == 7) {
            dateOffset = 0;
        }

        calendar.getChildren().clear();

        // Create the calendar grid
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                StackPane stackPane = new StackPane();

                // Rectangle as the background for each date
                Rectangle rectangle = new Rectangle();
                rectangle.setStroke(Color.WHITE);
                rectangle.setFill(Color.TRANSPARENT);
                rectangle.setWidth((calendar.getPrefWidth() / 7));
                rectangle.setHeight((calendar.getPrefHeight() / 6));
                stackPane.getChildren().add(rectangle);

                int calculatedDate = (j + 1) + (7 * i);
                if (calculatedDate > dateOffset) {
                    int currentDate = calculatedDate - dateOffset;
                    if (currentDate <= monthMaxDate) {
                        // Text representing the date
                        Text dateText = new Text(String.valueOf(currentDate));
                        dateText.setFill(Color.WHITE); // Set text color to white
                        dateText.setFont(Font.font("Candara", FontWeight.BOLD, 20));
                        stackPane.getChildren().add(dateText);

                        // Determine the current date
                        LocalDate currentLocalDate = LocalDate.of(dateFocus.getYear(), dateFocus.getMonthValue(), currentDate);

                        // Set click behavior for each date
                        stackPane.setOnMouseClicked(event -> {
                            try {
                                handleDateClick(event, currentLocalDate);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        });

                        // Highlight today's date
                        if (today.toLocalDate().equals(currentLocalDate)) {
                            rectangle.setStroke(Color.BLUE);
                        }
                    }
                }

                // Add the stack pane to the calendar
                calendar.getChildren().add(stackPane);
            }
        }
    }
    private void handleDateClick(MouseEvent event, LocalDate clickedDate) throws IOException {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Choose Action");
        alert.setHeaderText("What would you like to do?");
        alert.setContentText("Choose one of the following options.");

        ButtonType buttonTypeEvent = new ButtonType("Add Event");
        ButtonType buttonTypeNote = new ButtonType("Add Notes");
        ButtonType buttonTypeViewEvent = new ButtonType("View Event");
        ButtonType buttonTypeViewNotes = new ButtonType("View Notes");
        ButtonType buttonTypeCancel = new ButtonType("Cancel");

        alert.getButtonTypes().setAll(buttonTypeEvent, buttonTypeNote, buttonTypeViewEvent, buttonTypeCancel, buttonTypeViewNotes);

        alert.showAndWait().ifPresent(response -> {
            if (response == buttonTypeEvent) {
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("AddEvent.fxml"));
                    Parent root = loader.load();
                    AddEventController controller = loader.getController();
                    controller.setSelectedDate(clickedDate.atStartOfDay(dateFocus.getZone()));

                    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    Scene scene = new Scene(root);
                    stage.setScene(scene);
                    stage.show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else if (response == buttonTypeViewEvent) {
                try {
                    String eventData = readEventFile(clickedDate);
                    Alert eventAlert = new Alert(Alert.AlertType.INFORMATION);
                    eventAlert.setTitle("Event Details");
                    eventAlert.setHeaderText("Events for " + clickedDate);
                    eventAlert.setContentText(eventData);

                    eventAlert.showAndWait();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else if (response == buttonTypeNote) {
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("AddNotes.fxml"));
                    Parent root = loader.load();
                    AddNotesController controller = loader.getController();
                    controller.setSelectedDate(clickedDate.atStartOfDay(dateFocus.getZone()));

                    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    Scene scene = new Scene(root);
                    stage.setScene(scene);
                    stage.show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else if (response == buttonTypeViewNotes) {
                try {
                    String eventData = readNoteFile(clickedDate);
                    Alert eventAlert = new Alert(Alert.AlertType.INFORMATION);
                    eventAlert.setTitle("Event Details");
                    eventAlert.setHeaderText("Events for " + clickedDate);
                    eventAlert.setContentText(eventData);

                    eventAlert.showAndWait();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }else {
                System.out.println("User canceled the action.");
            }
        });
    }

    private String readNoteFile(LocalDate date) throws IOException {
        StringBuilder noteDetails = new StringBuilder();
        String targetDate = "Note Date: " + date;

        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream("notes.txt")) {
            if (inputStream == null) {
                throw new IOException("notes.txt not found in resources.");
            }

            Scanner fileScanner = new Scanner(inputStream);
            boolean matchFound = false;
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                if (line.contains(targetDate)) {
                    matchFound = true;
                    noteDetails.append(line).append("\n");

                    for (int i = 0; i < 2 && fileScanner.hasNextLine(); i++) {
                        noteDetails.append(fileScanner.nextLine()).append("\n");
                    }
                    noteDetails.append("----------------------------\n");
                }
            }

            if (!matchFound) {
                noteDetails.append("No events found for this date.");
            }
        }
        return noteDetails.toString();
    }
    private String readEventFile(LocalDate date) throws IOException {
        StringBuilder eventDetails = new StringBuilder();
        String targetDate = "Event Date: " + date;

        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream("events.txt")) {
            if (inputStream == null) {
                throw new IOException("events.txt not found in resources.");
            }

            Scanner fileScanner = new Scanner(inputStream);
            boolean matchFound = false;
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                if (line.contains(targetDate)) {
                    matchFound = true;
                    eventDetails.append(line).append("\n");

                    for (int i = 0; i < 2 && fileScanner.hasNextLine(); i++) {
                        eventDetails.append(fileScanner.nextLine()).append("\n");
                    }
                    eventDetails.append("----------------------------\n");
                }
            }

            if (!matchFound) {
                eventDetails.append("No events found for this date.");
            }
        }
        return eventDetails.toString();
    }
}
