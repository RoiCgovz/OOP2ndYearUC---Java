package com.sampleproject.sampleintellijproject;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.time.ZonedDateTime;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class AddEventController {

    // FXML fields for the UI elements
    @FXML
    public Text selectedDateText; // To display the selected date

    @FXML
    private TextField eventTitleField; // To input event title

    @FXML
    private TextArea eventDescriptionArea; // To input event description

    @FXML
    public Label SaveLabel_Event; // To save the event

    @FXML
    private Label CancelLabel_Event; // To cancel the event creation

    private ZonedDateTime selectedDate; // To store the selected date

    // This method will be called from the CalendarNavigationController
    public void setSelectedDate(ZonedDateTime selectedDate) {
        this.selectedDate = selectedDate;
        selectedDateText.setText("Selected Date: " + selectedDate.toLocalDate().toString());
    }

    // Event handler for the "Save" button
    @FXML
    private void handleSaveEvent() {
        String eventTitle = eventTitleField.getText();
        String eventDescription = eventDescriptionArea.getText();

        if (eventTitle.isEmpty() || eventDescription.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please fill in all fields.");
        } else {
            String eventDetails = "Event Date: " + selectedDate.toLocalDate() + "\n" +
                    "Title: " + eventTitle + "\n" +
                    "Description: " + eventDescription + "\n" +
                    "----------------------------\n";

            String filePath = "events.txt";

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
                writer.write(eventDetails);
                writer.flush();
                showAlert(Alert.AlertType.INFORMATION, "Saved", "Event saved!");
                backtoCalendarView();
            } catch (IOException e) {
                e.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Error", "An error occurred while saving the event.");
            }
        }
    }


    // Event handler for the "Cancel" button
    @FXML
    private void handleCancelEvent() throws IOException {
        Stage stage = (Stage) CancelLabel_Event.getScene().getWindow();
        backtoCalendarView();
        stage.show();
    }

    public void backtoCalendarView() throws IOException {
        switchScene("CALENDARFRONTPAGE.fxml");
    }


    private void switchScene(String fxmlFile) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
        Parent root = loader.load();
        Stage stage = (Stage) SaveLabel_Event.getScene().getWindow(); // You can use any Node in the current scene.
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }


    // Helper method to show alerts
    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
