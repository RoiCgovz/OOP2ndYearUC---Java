package com.sampleproject.sampleintellijproject;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class CalendarGUI extends Application {
    @Override
    public void start(Stage stage) {
        try
        {
            Parent root = FXMLLoader.load(getClass().getResource("MainFrontPage.fxml"));
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setResizable(false);
            stage.show();

        } catch (Exception e) {
            System.out.println("Cannot find fxml file    " + e.getMessage());

        }
    }
    public static void main(String[] args) {
        launch(args);
    }
}
