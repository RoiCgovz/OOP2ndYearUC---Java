import java.util.*;
import java.io.*;

public class ViewContacts 
{
    public final String File_Name = "Contacts.txt"; 
        
    public void contactDisplay()
    {
        try (BufferedReader reader = new BufferedReader(new FileReader(File_Name))) 
        {
            String line;
            System.out.println("\nContacts:");
            while ((line = reader.readLine()) != null) 
                {
                    System.out.println(line);
                }
        } 
        catch (IOException e) 
        {
            System.out.println("An error occurred while reading contacts.");
        }
    }
}
