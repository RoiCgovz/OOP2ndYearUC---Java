import java.io.*;
import java.util.*;

public class DeleteContact {
    private static final String File_Name = "contacts.txt";

    public void contactDelete(String nameToDelete) {
        List<String> contacts = new ArrayList<>();
        boolean found = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(File_Name))) 
        {
            String line;
            while ((line = reader.readLine()) != null) 
            {
                if (line.equals(nameToDelete)) 
                {
                    found = true;
                } 
                else 
                {
                    contacts.add(line);
                }
            }
        } 
        catch (IOException e) 
        {
            System.out.println("An error occurred while deleting contact.");
            return;
        }
        if (!found) 
        {
            System.out.println("Contact not found.");
            return;
        }
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(File_Name))) 
        {
            for (String contact : contacts) 
            {
                writer.write(contact);
                writer.newLine();
            }
            System.out.println("Contact deleted successfully.");
        } 
        catch (IOException e) 
        {
            System.out.println("An error occurred while saving contacts.");
        }
    }
}
