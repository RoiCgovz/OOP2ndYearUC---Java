import java.util.*;
import java.io.*;

public class AddContacts {
    
    public final String File_Name = "Contacts.txt";

    public void contactAdd(String name)
    {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(File_Name, true)))
        {
            writer.write(name);
            writer.newLine();
            System.out.println("Contact Added.");
            
        } catch (IOException e) {
            System.out.println("An error occured while adding the contact.");
        }
    }
}
