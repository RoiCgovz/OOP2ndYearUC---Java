import java.util.*;
import java.io.*;

public class ContactManagementSystem 
{
    public static void main(String[] args) 
    {
        Scanner scan = new Scanner(System.in);
        AddContacts addContact = new AddContacts();
        ViewContacts viewContacts = new ViewContacts();
        UpdateContacts updateContact = new UpdateContacts();
        DeleteContact deleteContact = new DeleteContact();

        while (true)
        {
            System.out.println("---------- Contact Management System ----------");
            System.out.println("---------- Press 1: Add Contact    ----------");
            System.out.println("---------- Press 2: View Contacts  ----------");
            System.out.println("---------- Press 3: Update Contact ----------");
            System.out.println("---------- Press 4: Delete Contact ----------");
            System.out.println("---------- Press 5: Exit           ----------");
            System.out.println("\n");
            
            System.out.print("Choose an option: ");
            int choice = scan.nextInt();
            scan.nextLine();
            
            switch (choice) 
            {
                case 1:
                System.out.print("Enter contact name: ");
                String name = scan.nextLine();
                addContact.contactAdd(name);
                    break;

                case 2:
                    viewContacts.contactDisplay();
                    break;

                case 3:
                    System.out.print("Enter the name of the contact to update: ");
                    String oldName = scan.nextLine();
                    System.out.print("Enter the new name: ");
                    String newName = scan.nextLine();
                    updateContact.contactUpdate(oldName, newName);
                    break;

                case 4:
                    System.out.print("Enter the name of the contact to delete: ");
                    String nameToDelete = scan.nextLine();
                    deleteContact.contactDelete(nameToDelete);
                    break;
                case 5:
                    System.out.println("Exiting....");
                    scan.close();
                    return; 
                default:
                    System.out.println("Invalid option. Please try again.");
                    break;
            }
        }
    }    
}

