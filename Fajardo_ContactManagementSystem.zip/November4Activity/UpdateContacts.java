import java.util.*;
import java.io.*;
public class UpdateContacts 
{
    public final String File_Name = "Contacts.txt";
    
    public void contactUpdate(String oldName, String newName)
    {
        List<String> contacts = new ArrayList<>();
        boolean found = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(File_Name))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.equals(oldName)) {
                    contacts.add(newName);
                    found = true;
                } else {
                    contacts.add(line);
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred while updating contacts.");
            return;
        }

        if (!found) {
            System.out.println("Contact not found.");
            return;
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(File_Name))) {
            for (String contact : contacts) {
                writer.write(contact);
                writer.newLine();
            }
            System.out.println("Contact updated successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred while saving contacts.");
        }
    }
}

