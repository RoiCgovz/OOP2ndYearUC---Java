import java.util.*;

class Node {
    String data;
    Node next;

    public Node(String data) {
        this.data = data;
        this.next = null;
    }
}

public class NodeList {
    Node head;
    int counter;

    public NodeList() {
        head = null;
        counter = 0;
    }

    boolean isEmpty() {
        return counter == 0;
    }

    boolean add(String item) {
        Node newNode = new Node(item);
        if (isEmpty()) {
            head = newNode; 
        } else {
            Node current = head;
            // Traverse to the end of the list
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode; 
        }
        counter++;
        return true;
    }

    boolean delete(int location) {
        if (isEmpty() || location < 0 || location >= counter) {
            return false; 
        }

        if (location == 0) {
            head = head.next; 
        } else {
            Node current = head;
            for (int i = 0; i < location - 1; i++) {
                current = current.next; 
            }
            current.next = current.next.next;
        }
        counter--;
        return true;
    }

    public void display() {
        if (!isEmpty()) 
        {
            Node temp = head;
            while (temp != null) 
            {
                System.out.println(temp.data);
                temp = temp.next;
            }
            System.out.println("\n");
        } 
        else 
        {
            System.out.println("Node is Empty");
        }
    }
}
