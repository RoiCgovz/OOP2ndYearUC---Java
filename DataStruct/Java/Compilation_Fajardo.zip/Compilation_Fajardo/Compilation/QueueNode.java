/*
   Roilene Vhinz Fajardo
   BSCS 2A
   11-10-2024
   8:11 PM
*/
public class QueueNode {
    private static class Node {
        Object value;
        Node next;

        public Node(Object value) {
            this.value = value;
            this.next = null;
        }
    }

    private Node front;
    private Node rear;
    private int count;
    private int maxSize; 

    
    public QueueNode(int maxSize) {
        this.front = null;
        this.rear = null;
        this.count = 0;
        this.maxSize = maxSize; 
    }

    public QueueNode() {
        this(80); 
    }

    public boolean isEmpty() {
        return front == null;
    }

    public boolean isFull() {
        return count >= maxSize; 
    }
    public boolean enqueue(Object val) {
        if (isFull()) {
            System.out.println("Queue is full. Cannot enqueue.");
            return false;
        }

        Node newNode = new Node(val);
        if (rear == null) { 
            front = rear = newNode;
        } else {
            rear.next = newNode;
            rear = newNode;
        }
        count++;
        return true;
    }

    public boolean dequeue() {
        if (isEmpty()) {
            return false;
        }
        front = front.next;
        if (front == null) { 
            rear = null;
        }
        count--;
        return true;
    }

    public Object front() {
        return isEmpty() ? null : front.value;
    }

    public void display() {
        if (isEmpty()) {
            System.out.println("Queue is empty...");
        } else {
            Node current = front;
            while (current != null) {
                System.out.println("[" + current.value + "]");
                current = current.next;
            }
        }
    }

    public int size() {
        return count;
    }
}
