import java.util.Scanner;

public class StackNodeMenu {
    public static void StackNodeMainMenu() {
        Scanner scanner = new Scanner(System.in);
        int choice;
        StackNode stack = new StackNode();

        do {
            System.out.println("\nStack Menu:");
            System.out.println("1. Push an element");
            System.out.println("2. Pop an element");
            System.out.println("3. Peek the top element");
            System.out.println("4. Display all elements");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // consume the newline character

            switch (choice) {
                case 1:
                    System.out.print("Enter a value to push: ");
                    String pushValue = scanner.nextLine();
                    stack.push(pushValue);
                    break;
                case 2:
                    if (stack.pop()) {
                        System.out.println("Element popped.");
                    } else {
                        System.out.println("Stack is empty. Cannot pop.");
                    }
                    break;
                case 3:
                    String peekValue = stack.peek();
                    if (peekValue != null) {
                        System.out.println("Top element: " + peekValue);
                    } else {
                        System.out.println("Stack is empty.");
                    }
                    break;
                case 4:
                    stack.display();
                    break;
                case 5:
                    System.out.println("Exiting program.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        } while (choice != 5);

    }
}
