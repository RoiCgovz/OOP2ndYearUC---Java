import java.util.*;

public class EvenOddColumnDisplay {
    public static void EvenOddMenu() {
        Scanner scanner = new Scanner(System.in);
        int[] numbers = new int[10];
        ArrayList<Integer> evens = new ArrayList<>();
        ArrayList<Integer> odds = new ArrayList<>();

        System.out.println("Enter 10 integer numbers:");

        for (int i = 0; i < 10; i++) {
            System.out.print("Number " + (i + 1) + ": ");
            numbers[i] = scanner.nextInt();

            if (numbers[i] % 2 == 0) {
                evens.add(numbers[i]);
            } else {
                odds.add(numbers[i]);
            }
        }

        int maxSize = Math.max(evens.size(), odds.size());


        System.out.println("\nEven\tOdd");

        for (int i = 0; i < maxSize; i++) {
            String evenValue = (i < evens.size()) ? String.valueOf(evens.get(i)) : "";
            String oddValue = (i < odds.size()) ? String.valueOf(odds.get(i)) : "";
            System.out.printf("%-8s%-8s\n", evenValue, oddValue);
        }
        System.out.println("");
    }
}
