public class StackNode {
    private Node top;
    private int count;

    // Node class for linked list
    private class Node {
        String data;
        Node next;

        public Node(String data) {
            this.data = data;
            this.next = null;
        }
    }

    // Constructor
    public StackNode() {
        top = null;
        count = 0;
    }

    // Check if the stack is empty
    private boolean isEmpty() {
        return count == 0;
    }

    // Push an element onto the stack
    public boolean push(String val) {
        Node newNode = new Node(val);
        newNode.next = top;
        top = newNode;
        count++;
        return true;
    }

    // Pop an element from the stack
    public boolean pop() {
        if (!isEmpty()) {
            top = top.next;
            count--;
            return true;
        }
        return false;
    }

    // Peek at the top element of the stack
    public String peek() {
        if (!isEmpty()) {
            return top.data;
        }
        return null;
    }

    // Display all elements in the stack
    public void display() {
        if (!isEmpty()) {
            Node current = top;
            while (current != null) {
                System.out.println("[" + current.data + "]");
                current = current.next;
            }
        } else {
            System.out.println("Stack is empty");
        }
    }

    public static void main(String[] args) {
        StackNode stack = new StackNode();
        stack.push("First");
        stack.push("Second");
        stack.push("Third");
        stack.display();

        System.out.println("Peek: " + stack.peek());
        stack.pop();
        stack.display();
    }
}
