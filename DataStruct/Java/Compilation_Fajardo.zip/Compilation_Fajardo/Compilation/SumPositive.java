import java.util.Scanner;

public class SumPositive {
    public static void SumPositiveMenu() {
        Scanner scanner = new Scanner(System.in);
        int[] numbers = new int[10];
        int totalSum = 0;
        int totalProduct = 1;

        System.out.println("Enter 10 integer numbers:");

        for (int i = 0; i < 10; i++) {
            System.out.print("Number " + (i + 1) + ": ");
            numbers[i] = scanner.nextInt();

            
            if (numbers[i] > 0) {
                totalSum += numbers[i];
                totalProduct *= numbers[i];
            }
        }

        System.out.println("\nResults:");
        System.out.println("Total Sum of numbers greater than 0: " + totalSum);

        if (totalSum > 0) {
            System.out.println("Total Product of numbers greater than 0: " + totalProduct);
        } else {
            System.out.println("No positive numbers were entered; product is undefined.");
        }
    }
}
