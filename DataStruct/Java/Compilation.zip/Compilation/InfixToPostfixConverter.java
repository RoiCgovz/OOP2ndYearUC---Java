import java.util.*;

public class InfixToPostfixConverter {
    private static int precedence(char operator) {
        switch (operator) {
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
                return 2;
            case '^':
                return 3;
            default:
                return -1;
        }
    }

    private static boolean isOperator(char ch) {
        return ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '^';
    }

    public static String infixToPostfix(String infix, int stackSize) {
        oneStack stack = new oneStack(stackSize);
        char[] postfix = new char[infix.length()];
        int index = 0;

        for (int i = 0; i < infix.length(); i++) {
            char current = infix.charAt(i);

            if (Character.isLetterOrDigit(current)) 
            {
                postfix[index++] = current;
            } 
            else if (current == '(') 
            {
                stack.push(current);
            } 
            else if (current == ')') 
            {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    postfix[index++] = stack.pop();
                }
                stack.pop();
            } 
            else if (isOperator(current)) 
            {
                while (!stack.isEmpty() && precedence(stack.peek()) >= precedence(current)) {
                    postfix[index++] = stack.pop();
                }
                stack.push(current);
            }
        }

        while (!stack.isEmpty())
        {
            postfix[index++] = stack.pop(); 
        }
        return new String(postfix, 0, index); 
    }

    // Evaluate postfix expression
    public static int evaluatePostfix(String postfix) {
        Stack<Integer> stack = new Stack<>();
        for (char ch : postfix.toCharArray()) {
            if (Character.isDigit(ch)) {
                stack.push(ch - '0'); // Convert char to int
            } else if (isOperator(ch)) {
                int b = stack.pop(); // Second operand
                int a = stack.pop(); // First operand
                switch (ch) {
                    case '+': stack.push(a + b); break;
                    case '-': stack.push(a - b); break;
                    case '*': stack.push(a * b); break;
                    case '/': stack.push(a / b); break;
                    case '^': stack.push((int) Math.pow(a, b)); break;
                }
            }
        }
        return stack.pop(); // Final result
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the stack size: ");
        int stackSize = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter the infix expression: ");
        String infixExpression = scanner.nextLine();

        try {
            String postfixExpression = infixToPostfix(infixExpression, stackSize);
            System.out.println("Postfix Expression: " + postfixExpression);
            int result = evaluatePostfix(postfixExpression);
            System.out.println("Evaluation Result: " + result);
        } catch (RuntimeException e) {
            System.err.println("Error: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}
