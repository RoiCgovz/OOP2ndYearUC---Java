import java.util.Scanner;

public class QueueNodeMenu {
    public static void QueueNodeMainMenu() {
        Scanner scanner = new Scanner(System.in);
        QueueNode queue = new QueueNode();
        
        while (true) {
            System.out.println("Queue Menu:");
            System.out.println("1. Enqueue");
            System.out.println("2. Dequeue");
            System.out.println("3. Display Front");
            System.out.println("4. Display Queue");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            
            int choice = scanner.nextInt();
            
            switch (choice) {
                case 1:
                    // Enqueue
                    System.out.print("Enter value to enqueue: ");
                    scanner.nextLine(); // Consume the newline
                    String value = scanner.nextLine();
                    queue.enqueue(value);
                    System.out.println("Enqueued: " + value);
                    break;
                
                case 2:
                    // Dequeue
                    if (queue.dequeue()) {
                        System.out.println("Dequeued front element.");
                    } else {
                        System.out.println("Queue is empty, nothing to dequeue.");
                    }
                    break;
                    
                case 3:
                    // Display Front
                    Object front = queue.front();
                    if (front != null) {
                        System.out.println("Front: " + front);
                    } else {
                        System.out.println("Queue is empty.");
                    }
                    break;
                
                case 4:
                    // Display Queue
                    queue.display();
                    break;
                
                case 5:
                    // Exit
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                
                default:
                    System.out.println("Invalid choice, try again.");
            }
            
            System.out.println();
        }
    }
}
