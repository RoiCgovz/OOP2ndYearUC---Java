import java.util.Scanner;

public class StackArrayMenu {
    public static void StackArrayMainMenu() {
        Scanner scanner = new Scanner(System.in);
        StackArray stack = new StackArray(5); // Set max size for the stack as 5 for example
        
        while (true) {
            System.out.println("Stack Menu:");
            System.out.println("1. Push");
            System.out.println("2. Pop");
            System.out.println("3. Peek");
            System.out.println("4. Display Stack");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character
            
            switch (choice) {
                case 1:
                    // Push
                    System.out.print("Enter value to push: ");
                    String value = scanner.nextLine();
                    if (stack.push(value)) {
                        System.out.println("Pushed: " + value);
                    } else {
                        System.out.println("Stack is full. Cannot push.");
                    }
                    break;
                
                case 2:
                    // Pop
                    if (stack.pop()) {
                        System.out.println("Popped top element.");
                    } else {
                        System.out.println("Stack is empty, nothing to pop.");
                    }
                    break;
                    
                case 3:
                    // Peek
                    String topElement = stack.peek();
                    if (topElement != null) {
                        System.out.println("Top of the stack: " + topElement);
                    } else {
                        System.out.println("Stack is empty.");
                    }
                    break;
                
                case 4:
                    // Display Stack
                    stack.display();
                    break;
                
                case 5:
                     // Exit
                     System.out.println("Exiting...");
                     scanner.close();
                    break;
                
                default:
                    System.out.println("Invalid choice. Try again.");
            }
            
            System.out.println();
        }
    }
}
