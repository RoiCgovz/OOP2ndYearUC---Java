import java.util.Scanner;

public class Duplicates {
    public static void DuplicatesMenu() {
        Scanner scanner = new Scanner(System.in);
        int[] numbers = new int[10];
        int[] uniqueNumbers = new int[10];
        int uniqueCount = 0;

        System.out.println("Enter 10 integer numbers:");

        for (int i = 0; i < 10; i++) {
            System.out.print("Number " + (i + 1) + ": ");
            numbers[i] = scanner.nextInt();

            // Check if the number is already in the uniqueNumbers array
            boolean isUnique = true;
            for (int j = 0; j < uniqueCount; j++) {
                if (uniqueNumbers[j] == numbers[i]) {
                    isUnique = false;
                    break;
                }
            }

            // Add to uniqueNumbers array if it is unique
            if (isUnique) {
                uniqueNumbers[uniqueCount] = numbers[i];
                uniqueCount++;
            }
        }

        // Display header
        System.out.println("\nAll Numbers\t Numbers with no Duplicates");

        // Determine maximum column length
        int maxSize = Math.max(numbers.length, uniqueCount);

        // Display numbers in columns
        for (int i = 0; i < maxSize; i++) {
            String allNumber = (i < numbers.length) ? String.valueOf(numbers[i]) : "";
            String uniqueNumber = (i < uniqueCount) ? String.valueOf(uniqueNumbers[i]) : "";
            System.out.printf("%-12s%-12s\n", allNumber, uniqueNumber);
        }

        scanner.close();
    }
}
