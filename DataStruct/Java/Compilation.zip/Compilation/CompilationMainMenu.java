import java.util.*;

public class CompilationMainMenu {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String choice;
        boolean loop = true;
 
        while (loop)
        {
           System.out.println("\n-- ACTIVIY COMPILATION --");
           System.out.println("\n-- Choose a Number below --");
           System.out.println("1] Activity 1: Duplicates");
           System.out.println("2] Activity 2: Compute the sum of numbers greater than 0.");
           System.out.println("3] Activity 3: Odd and Even Numbers.");
           System.out.println("4] Activity 4: Stack Array.");
           System.out.println("5] Activity 5: Stack Node.");
           System.out.println("6] Activity 6: NodeList.");
           System.out.println("7] Activity 7: QueueArray");
           System.out.println("8] Activity 8: QueueNode");
           System.out.println("9] Activity 9: Infix to Postfix Conversion");
           System.out.println("X] Exit");
           
           choice = scan.nextLine().trim().toUpperCase();
           
           switch(choice)
           {
                case "1":
                Duplicates.DuplicatesMenu();
                break;
              case "2":
                SumPositive.SumPositiveMenu();
                break;
              case "3":
                EvenOddColumnDisplay.EvenOddMenu();
                break;  
              case "4":
                StackArrayMenu.StackArrayMainMenu();
                break;
              case "5":
                StackNodeMenu.StackNodeMainMenu();
                break;
              case "6":
                NodelistMainMenu.NodeListMenu();
                break;
              case "7":
                QueueArrayMenu.ArrayQueueMenu();
                break;
              case "8":
                QueueNodeMenu.QueueNodeMainMenu();
                break;
              case "9":
                InfixToPostfixConverter.main(args);
                break;
              case "X":
                 System.out.println("Exiting the Program...");
                 loop = false;
                 break;
                 
              default:
                 System.out.println("Error, please input the correct symbol. Please try again");
           }
        }
        scan.close();   
     }      
}

