import java.util.*;

public class NodelistMainMenu
{ 
  public static void NodeListMenu()
  {
    NodeList nd = new NodeList();
    Scanner scanner = new Scanner(System.in);

    while (true) {
        System.out.println("\n--- NodeList Menu---");
        System.out.println("1. Add Node");
        System.out.println("2. Delete Node");
        System.out.println("3. Display Nodes");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
        int choice;
        try {
            choice = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a number between 1 and 4.");
            continue;
        }

        switch (choice) {
            case 1: // Add Node
                System.out.print("Enter data to add: ");
                String data = scanner.nextLine();
                
                if (nd.add(data)) {
                    System.out.println("Node added successfully.");
                } else {
                    System.out.println("Failed to add node.");
                }
                break;

            case 2: // Delete Node
                if (nd.isEmpty()) {
                    System.out.println("The list is empty. Nothing to delete.");
                    break;
                }

                System.out.print("Enter the position (0-based index) to delete: ");
                int position;
                try {
                    position = Integer.parseInt(scanner.nextLine());
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a valid number.");
                    break;
                }

                if (nd.delete(position)) {
                    System.out.println("Node deleted successfully.");
                } else {
                    System.out.println("Invalid position. Deletion failed.");
                }
                break;

            case 3: // Display Nodes
                System.out.println("\nCurrent List:");
                nd.display();
                break;

            case 4: // Exit
                System.out.println("Exiting the program. Goodbye!");
                scanner.close();
                return;

            default:
                System.out.println("Invalid choice. Please select a number between 1 and 4.");
        }
    }
  }
}