import java.util.*;
public class StackMenu{
   public static void main(String... args){
       StackArray  s= new StackArray();
       Scanner scan = new Scanner(System.in);

       int size;
       String val, choice;
       boolean choiceLoop=true;
               System.out.println("Enter Stack size: ");
        size = scan.nextInt();
                      
       while (choiceLoop) 
       {

       System.out.print("[1] Push an item." );
       System.out.print("[2] Pop." );
       System.out.print("[3] Peek." );
       System.out.print("[4] Display Stack." );
       System.out.print("[x] Exit Program. " );
       System.out.println("Enter choice: ");
       choice = scan.nextLine().toLowerCase();


            switch (choice)
            {

                case "1":
                val= scan.nextLine();
                if(s.push)
                    System.out.println("Stack pushed successfully");
                 else
                    System.out.println("Stack unsuccessful");
                break;
            case "2":
                 val= scan.nextLine();
          if(s.pop)
            System.out.println("Stack popped");
                else
            System.out.println("Stack is empty, popped unsuccessfully");
          break;
       case "3":
            System.out.println(s.peek());
       break;
       case "4":
            System.out.println(s.display);
       break;
       case "x":
            choiceLoop = false;
       break;
       default:
       System.out.println("Invalid input");
       break;
            }
       }
   }
}





