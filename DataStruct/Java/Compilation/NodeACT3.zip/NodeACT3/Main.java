import java.util.*;

public class Main 
{ 
   public static void main(String[] args) 
   {
     NodeList n = new NodeList();
     n.add("1");
     n.add("7");
     n.add("2");
     n.add("9");
     n.display(); 
     n.delete(1);
     n.display(); 
   }
}